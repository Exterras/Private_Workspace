int fault_check(int _cnt, int _faultChkTimes, double _incPercent, double _minFault, double* _curData);
