#include <stdio.h>
#include <stdbool.h> // bool 타입을 사용하기 위한 라이브러리 삽입

#include "fileManager.h" // 파일 입출력을 위한 라이브러리 삽입
#include "fault_check.h" // 전류를 삽입하였을 대 고장을 판별하는 라이브러리 삽입

void fault_detection(void);
void fault_handler(int _cnt, int _faultChkTimes);

struct faultChkValue {
    char *curName;
    int curLen;
    int faultChkTimes;
    double incPercent;
    double minFault;
    int cnt;
};

int main()
{
    fault_detection();
    return 0;
}

void fault_detection(void){
    struct faultChkValue A_0;
   // struct faultChkValue A_45;
   // struct faultChkValue A_90;

    A_0.curName = "A_0.txt";
    A_0.curLen = 101;
    A_0.faultChkTimes = 10;
    A_0.incPercent = 10;
    A_0.minFault = 0.2;
    A_0.cnt = fault_check(A_0.curLen,
                          A_0.faultChkTimes,
                          A_0.incPercent,
                          A_0.minFault,
                          file_save(A_0.curName));
    /*
    A_45.curName = "A_45.txt";
    A_45.curLen = 101;
    A_45.faultChkTimes = 10;
    A_45.incPercent = 10;
    A_45.minFault = 0.2;
    A_45.cnt = fault_check(A_45.curLen,
                          A_45.faultChkTimes,
                          A_45.incPercent,
                          A_45.minFault,
                          file_save(A_45.curName));

    A_90.curName = "A_90.txt";
    A_90.curLen = 101;
    A_90.faultChkTimes = 10;
    A_90.incPercent = 10;
    A_90.minFault = 0.2;
    A_90.cnt = fault_check(A_90.curLen,
                          A_90.faultChkTimes,
                          A_90.incPercent,
                          A_90.minFault,
                          file_save(A_90.curName));*/
    fault_handler(A_0.cnt, A_0.faultChkTimes);
   // fault_handler(A_45.cnt);
   // fault_handler(A_90.cnt);

}

void fault_handler(int _cnt, int _faultChkTimes){
    if(_cnt >= _faultChkTimes){
        printf("cnt : %d, fault", _cnt);
    } else {
        printf("cnt : %d, normal", _cnt);
    }
}
